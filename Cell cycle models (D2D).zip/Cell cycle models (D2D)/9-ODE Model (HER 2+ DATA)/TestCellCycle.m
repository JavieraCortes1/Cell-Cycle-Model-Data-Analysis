% (Advanced topic) Equilibration using rootfinding
arInit;
arLoadModel('ModelTest_new'); % on/off boolean  "1/(1+palbociclib)"    ((1+step1(t,0,6.2832,palbociclib)))*
arLoadData('condG1S_new');
% arLoadData('conditionPalbo');

% Compile the model
arCompileAll(true);
arSave('my_workspace');

%% Fit the model
% 
% arFit
% arPlot

%% Numerical settings
ar.config.atol     = 1e-8;
ar.config.rtol     = 1e-8;
ar.config.maxsteps = 1e5; %;
ar.config.fiterrors = 0;  % -1 1

% Optimizer settings
ar.config.optim.TolFun           = 1e-4;
ar.config.optim.PrecondBandWidth = inf;
ar.config.optim.Display          = 'iter';
ar.config.optim.MaxIter          = 1e4;% 'arIterateUntilConvergence';%
ar.config.optimizer              = 1; % 1=lsqnonlin 2=fmincon 3=particle-swarm 4=STRSCNE ... ar.config.optimizers for see all


%% Set parameters
% arLoadPars('bestFit')
% arFindInputs;

multistart_runs = 500; % total 
runs_per_instance = 10; % por cada matlab
parallel_instances = multistart_runs / runs_per_instance;

conf.pwd = pwd;
conf.d2dpath = fileparts(which('arInit.m'));
conf.workspace = ar.config.savepath;
conf.parIn = parallel_instances; % number of matlab instances
conf.totNum = ceil(multistart_runs/parallel_instances)*...
    parallel_instances; % extend total number of multistart runs to the next multiple of parallel_instances without loss of computation time

save('parallel_conf.mat', 'conf');

for icall = 1:parallel_instances
    system(sprintf('cd "%s"; sbatch d2d_submit.sh %i', conf.pwd, icall));
end

% arPlotChi2s
% arPlot;
% arMergeFitsCluster('par_result')
%% Steady State
% arClearEvents; % Clears events (required!)
% arFindInputs;
% arSteadyState(1,arFindCondition('condition1', 'exact'), arFindCondition('conditionPalbo', 'exact'));
% arSimu(true,true,true); arChi2(true);
% arPlotY;

