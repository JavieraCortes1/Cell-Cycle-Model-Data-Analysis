% Join results
load matlab_workspace100x20_solver1.mat

ar.timing=[ar1.timing,ar2.timing,ar3.timing,ar4.timing,ar5.timing,ar6.timing,ar7.timing,ar8.timing,ar9.timing];
ar.chi2s=[ar1.chi2s,ar2.chi2s,ar3.chi2s,ar4.chi2s,ar5.chi2s,ar6.chi2s,ar7.chi2s,ar8.chi2s,ar9.chi2s];
ar.ps=[ar1.ps,ar2.ps,ar3.ps,ar4.ps,ar5.ps,ar6.ps,ar7.ps,ar8.ps,ar9.ps];
ar.exitflag=[ar1.exitflag,ar2.exitflag,ar3.exitflag,ar4.exitflag,ar5.exitflag,ar6.exitflag,ar7.exitflag,ar8.exitflag,ar9.exitflag];