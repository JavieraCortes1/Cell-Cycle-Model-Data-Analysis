
close all;
clc;

%% Compile model
arInit
arLoadModel('model_CellCycle');
arLoadData('CellCycleData',1);
arCompileAll;
% arSave('my_workspace');
% arFindInputs;
%% Constraint parameters
% ar.lb = 0.01 * ones(size(ar.lb)); % lower parameter bounds
% ar.ub = 120 * ones(size(ar.ub)); % upper parameter bounds
% % ar.ub(31)=5;
% ar.ub(34)=5;
% ar.ub(42)=3;

% ar.ub(14)=5;
% ar.ub(45)=10;

%% Numerical settings
ar.config.atol     = 1e-8;
ar.config.rtol     = 1e-8;
ar.config.maxsteps = 1e5; %;
ar.config.fiterrors = 0;  % -1 1

% Optimizer settings
ar.config.optim.TolFun           = 1e-4;
ar.config.optim.PrecondBandWidth = inf;
ar.config.optim.Display          = 'iter';
ar.config.optim.MaxIter          = 1e4;% 'arIterateUntilConvergence';%
ar.config.optimizer              = 1; % 1=lsqnonlin 2=fmincon 3=particle-swarm 4=STRSCNE ... ar.config.optimizers for see all


%% Set parameters
% arLoadPars('bestFit')
% arFindInputs;


%% Visualization
% arSimu(true,true,true);
% arPlot;
% arSetParallelThreads(20)
arFitLHS(2000)
ar_2000_1=ar;
save ar_2000_1
