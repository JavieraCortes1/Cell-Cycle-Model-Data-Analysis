close all;
clc;

%% Compile model
arInit
arLoadModel('model_CellCycle');
arLoadData('CellCycleData',1);
arCompileAll;
arSave('my_workspace');

% arFindInputs;
%% Constraint parameters
% ar.lb = 0.01 * ones(size(ar.lb)); % lower parameter bounds
% ar.ub = 120 * ones(size(ar.ub)); % upper parameter bounds
% % ar.ub(31)=5;
% ar.ub(34)=5;
% ar.ub(42)=3;

% ar.ub(14)=5;
% ar.ub(45)=10;

%% Numerical settings
ar.config.atol     = 1e-8;
ar.config.rtol     = 1e-8;
ar.config.maxsteps = 1e5; %;
ar.config.fiterrors = 0;  % -1 1

% Optimizer settings
ar.config.optim.TolFun           = 1e-4;
ar.config.optim.PrecondBandWidth = inf;
ar.config.optim.Display          = 'iter';
ar.config.optim.MaxIter          = 1e4;% 'arIterateUntilConvergence';%
ar.config.optimizer              = 1; % 1=lsqnonlin 2=fmincon 3=particle-swarm 4=STRSCNE ... ar.config.optimizers for see all


%% Set parameters
% arLoadPars('bestFit')
% arFindInputs;

multistart_runs = 500; % total 
runs_per_instance = 10; % por cada matlab
parallel_instances = multistart_runs / runs_per_instance;

conf.pwd = pwd;
conf.d2dpath = fileparts(which('arInit.m'));
conf.workspace = ar.config.savepath;
conf.parIn = parallel_instances; % number of matlab instances
conf.totNum = ceil(multistart_runs/parallel_instances)*...
    parallel_instances; % extend total number of multistart runs to the next multiple of parallel_instances without loss of computation time

save('parallel_conf.mat', 'conf');

%%
for icall = 1:parallel_instances
    system(sprintf('cd "%s"; sbatch d2d_submit.sh %i', conf.pwd, icall));
end

% doWork(icall)

%% Visualization
% arSimu(true,true,true);
% arPlot;
% arMergeFitsCluster('par_result')


%% Profiles likelihood
arPLEInit
ple
plePlotMulti