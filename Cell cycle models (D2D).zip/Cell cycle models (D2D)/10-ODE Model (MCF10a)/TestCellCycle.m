% Cell cycle model 10-ODE
arInit;
arLoadModel('ModelTest_new'); % on/off boolean  "1/(1+palbociclib)"    ((1+step1(t,0,6.2832,palbociclib)))*
arLoadData('condG1S_new');
% arLoadData('condG2M');
% arLoadData('conditionPalbo');
% arLoadData('conditionNoco');

% Compile the model  -1697.01
arCompileAll(true);


%% Fit the model

% arFit
arPlot

% arFitLHS(10)
% arPlotChi2s


%% Steady State
% Palbo
% model=1;
% arFindInputs;
% arSteadyState(model,arFindCondition('conditionPalbo', 'exact'), arFindCondition('conditionPalbo', 'exact'));
% arSteadyState(model,arFindCondition('conditionNoco', 'exact'), arFindCondition('conditionNoco', 'exact'));

% arPlotEquilibration(model,1, [10] )
% arClearEvents; % Clears events (required!)
% arSimu(true,true,true); arChi2(true);
% arPlotY;

